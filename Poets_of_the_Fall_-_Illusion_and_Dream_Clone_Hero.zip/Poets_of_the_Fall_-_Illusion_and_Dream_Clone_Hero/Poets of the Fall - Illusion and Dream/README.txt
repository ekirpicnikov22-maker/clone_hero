Poets of the Fall - Illusion & Dream
Clone Hero custom chart

Instrument:
- 5-fret Guitar
- Expert

Chart design:
- Medium-hard verses
- Dense choruses with chord changes
- Automatic HOPO-friendly 16th-note runs
- Hard final guitar solo
- Star Power phrases and section markers
- No notes during the silent/spoken coda

Installation:
1. Extract this folder into Clone Hero/Songs.
2. Keep notes.mid, song.ogg, song.ini and album.png together.
3. Run Settings -> General -> Scan Songs.
