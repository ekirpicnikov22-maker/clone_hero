Poets of the Fall - War — Clone Hero FIXED

This version uses notes.mid + song.ogg for maximum Clone Hero compatibility.

Install:
1. Copy the folder "Poets of the Fall - War (Clone Hero FIXED)" directly into your Clone Hero Songs folder.
2. In Clone Hero: Settings -> General -> Scan Songs.
3. Search for: War / Poets of the Fall.

Important: copy the FOLDER, not the ZIP itself.
