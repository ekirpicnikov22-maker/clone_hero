DEATHSQUAD — M.O.B.

Riff-synced version:
- timings are driven primarily by low/mid-frequency riff attacks instead of generic full-mix onsets;
- fret direction follows the detected low/mid melodic contour;
- strong riff/beat accents become compact chords on Hard/Expert;
- 4 difficulties are included: Easy / Medium / Hard / Expert;
- a smoothed local tempo map is written into notes.mid.

Positions:
Easy: 290
Medium: 486
Hard: 711
Expert: 935
